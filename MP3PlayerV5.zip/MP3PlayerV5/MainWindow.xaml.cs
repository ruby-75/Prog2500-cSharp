﻿using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Security.Policy;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using Microsoft.Win32;
using TagLib;

namespace MP3Player
{
    public partial class MainWindow : Window
    {
        private MediaPlayer mediaPlayer = new MediaPlayer(); // MediaPlayer to play audio
        private List<string> mp3Files = new List<string>(); // List to store MP3 files
        private int currentSongIndex = -1; // Index of currently playing song
        private FileSystemWatcher fileWatcher;
        private DispatcherTimer timer;  // Define a DispatcherTimer object
        private DispatcherTimer sliderUpdateTimer;

        // Define variables to store edited song information
        private string editedSongName;
        private string editedArtist;
        private string editedAlbum;
        private string editedYear;
       
       

        public MainWindow()
        {
            InitializeComponent();
            InitializeFileSystemWatcher(); // Initialize the FileSystemWatcher
            LoadEditedInformation(); // Load edited song information on startup
            LoadMp3Files(); // Load MP3 files in the folder
            InitializeTimer(); // Initialize the timer         
            mediaPlayer.MediaEnded += MediaPlayer_MediaEnded; // Subscribe to the MediaEnded event
            mediaPlayer.MediaOpened += MediaPlayer_MediaOpened; // Subscribe to the MediaOpened event
            sliderUpdateTimer = new DispatcherTimer();
            sliderUpdateTimer.Interval = TimeSpan.FromMilliseconds(100); // Adjust the interval as needed
            sliderUpdateTimer.Tick += SliderUpdateTimer_Tick;
            Loaded += MainWindow_Loaded; // Attach event handler when the window loads
        }

        
        private void Timer_Tick(object sender, EventArgs e)
        {
            // Update the playback time
            UpdatePlaybackTime();

            // Debugging: Print the current position of the media player
            //Debug.WriteLine("Current Position: " + mediaPlayer.Position);
        }
        

        // Event handler for MediaOpened event
        private void MediaPlayer_MediaOpened(object sender, EventArgs e)
        {
            // When media is opened, set the maximum value of the slider
            TimerSlider.Maximum = mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds;

            // Start the slider update timer
            sliderUpdateTimer.Start();

            //timer.Start();  // Start the timer when media starts playing
            //UpdatePlaybackTime(); // Update playback time when media is opened

            // Debugging: Print a message when media is opened
            // Debug.WriteLine("Media Opened");
        }

        private void UpdatePlaybackTime()
        {
            if (mediaPlayer.NaturalDuration.HasTimeSpan)
            {
                // Update current playback time
                lblCurrenttime.Text = mediaPlayer.Position.ToString(@"mm\:ss");

                // Update total length of the song
                lblMusiclength.Text = mediaPlayer.NaturalDuration.TimeSpan.ToString(@"mm\:ss");
            }
        }


        // Event handler for MediaEnded event
        private void MediaPlayer_MediaEnded(object sender, EventArgs e)
        {
            // Stop the timer when media playback ends
            timer.Stop();

            // Play the next song
            PlayNextSong();
        }


        private void InitializeTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
        }

        
        private void InitializeFileSystemWatcher()
        {
            // Directory path containing MP3 files
            string folderPath = @"C:\music";

            // Initialize the FileSystemWatcher
            fileWatcher = new FileSystemWatcher(folderPath);
            fileWatcher.IncludeSubdirectories = false;
            fileWatcher.Filter = "*.mp3";

            // Subscribe to the Created event
            fileWatcher.Created += FileWatcher_Created;

            // Enable the FileSystemWatcher
            fileWatcher.EnableRaisingEvents = true;
        }


        private void FileWatcher_Created(object sender, FileSystemEventArgs e)
        {
            // A new file is created in the directory
            // Add the new file to the list of MP3 files
            mp3Files.Add(e.FullPath);
        }


        private void LoadMp3Files()
        {
            // Directory path containing MP3 files
            string folderPath = @"C:\music";

            try
            {
                // Get all MP3 files in the folder
                mp3Files.AddRange(Directory.GetFiles(folderPath, "*.mp3"));

                // Start playing the first song
                PlayNextSong();
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while loading MP3 files: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void PlayNextSong()
        {
            if (mp3Files.Count == 0)
            {
                MessageBox.Show("No MP3 files found in the folder.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Increment the index to play the next song
            currentSongIndex++;
            if (currentSongIndex >= mp3Files.Count)
                currentSongIndex = 0; // Loop back to the first song

            // Play the next song
            try
            {
                mediaPlayer.Open(new Uri(mp3Files[currentSongIndex]));
                mediaPlayer.Play();
                UpdateUI(mp3Files[currentSongIndex]);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while playing the next song: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void PlayPreviousSong()
        {
            if (mp3Files.Count == 0)
            {
                MessageBox.Show("No MP3 files found in the folder.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Decrement the index to play the previous song
            currentSongIndex--;
            if (currentSongIndex < 0)
                currentSongIndex = mp3Files.Count - 1; // Loop to the last song

            // Play the previous song
            PlaySongAtIndex(currentSongIndex);
        }


        private void PlaySongAtIndex(int index)
        {
            // Play the song at the specified index
            try
            {
                mediaPlayer.Open(new Uri(mp3Files[index]));
                mediaPlayer.Play();
                UpdateUI(mp3Files[index]);
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while playing the song: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void btnPNext_Click(object sender, RoutedEventArgs e)
        {
            PlayNextSong(); // Play the next song when the button is clicked
        }
    

        // Method to handle mouse drag event on the window
        private void Card_MouseDown(object sender, MouseButtonEventArgs e)
        {
            DragMove(); // Allows dragging the window
        }


        // Method to handle the close button click event
        private void btnClose_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown(); // Shutdown the application
        }


        private void btnPause_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Pause(); // Pause the audio playback             
            timer.Stop();  // Stop the timer when media is paused
        }


        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
          mediaPlayer.Play(); // Play the audio file
          timer.Start();  // Start the timer when media starts playing
          UpdatePlaybackTime(); // Update the playback time immediately
        }

        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Stop(); //Stop audio playback
            timer.Stop(); 
        }

        


       

        private void LoadEditedInformation()
        {
            // Load edited song information from a file or database
            // Example: Read the information from a text file
            if (System.IO.File.Exists("Edits/edited_song_info.txt"))
            {
                string[] lines = System.IO.File.ReadAllLines("Edits/edited_song_info.txt");
                if (lines.Length >= 4)
                {
                    editedSongName = lines[0];
                    editedArtist = lines[1];
                    editedAlbum = lines[2];
                    editedYear = lines[3];
                }
            }

            // Display the loaded information in the UI
            lblSongname.Text = editedSongName;
            txtArtist.Text = editedArtist;
            txtAlbum.Text = editedAlbum;
            txtYear.Text = editedYear;
        }


        // Method to handle the open file button click event
        private void btnFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog(); // Open file dialog
            openFileDialog.Filter = "MP3 files (*.mp3)|*.mp3|All files (*.*)|*.*"; // Filter for mp3 files
            if (openFileDialog.ShowDialog() == true) // If file is selected
            {
                try
                {
                    // Open and play the selected MP3 file
                    mediaPlayer.Open(new Uri(openFileDialog.FileName));
                    mediaPlayer.Play();
                    // Update UI with file details
                    UpdateUI(openFileDialog.FileName);
                }
                catch (Exception ex) // Handle exceptions
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error); // Show error message
                }
            }
        }


        // Method to update UI with file details
        private void UpdateUI(string filePath)
        {
            //// Extract the song name from the file path and Update song name
            lblSongname.Text = Path.GetFileNameWithoutExtension(filePath);

            // Retrieve additional song information (e.g., artist, album, year) if available
            // For demonstration purposes, let's assume you have methods to retrieve this information
            string artist = GetArtist(filePath);
            string album = GetAlbum(filePath);
            string year = GetYear(filePath);

            // Set the text for TextBoxes
            //txtArtist.Text = artist;
            //txtAlbum.Text = album;
           // txtYear.Text = year;

            // Update image
            string imgPath = $"{Path.GetDirectoryName(filePath)}\\Images\\musicnote.png";
            if (System.IO.File.Exists(imgPath)) // If image file exists
                Musicimg.Source = new BitmapImage(new Uri(imgPath)); // Set image source

            SetAlbumArt(filePath); // Set album art

            // Check if NaturalDuration is valid before accessing TimeSpan
            if (mediaPlayer.NaturalDuration.HasTimeSpan)
            {
                // Update music length
                lblMusiclength.Text = mediaPlayer.NaturalDuration.TimeSpan.ToString(@"mm\:ss");
            }
            else
            {
                lblMusiclength.Text = "00:00"; // Set default duration if not available
            }
        }


        private void btnPRewind_Click(object sender, RoutedEventArgs e)
        {
            PlayPreviousSong(); // Play the previous song when the button is clicked
        }

       

        private void SliderUpdateTimer_Tick(object sender, EventArgs e)
        {
            // Update the slider value based on the current position of the media player
            if (mediaPlayer != null && mediaPlayer.NaturalDuration.HasTimeSpan)
            {
                TimerSlider.Value = mediaPlayer.Position.TotalSeconds;
            }
        }


        private void TimerSlider_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            // Check if the mediaPlayer is initialized and is not null
            if (mediaPlayer != null)
            {
                // Calculate the position in the song based on the slider's value
                //double newPosition = mediaPlayer.NaturalDuration.TimeSpan.TotalSeconds * (TimerSlider.Value / 100.0);

                // Set the playback position of the song to the calculated position
                // mediaPlayer.Position = TimeSpan.FromSeconds(newPosition);

                // Set the playback position of the song to the slider's value
                mediaPlayer.Position = TimeSpan.FromSeconds(TimerSlider.Value);

                // Update the playback time
                UpdatePlaybackTime();
            }
        }


        private string GetArtist(string filePath)
        {
            try
            {
                var file = TagLib.File.Create(filePath);
                return file.Tag.FirstPerformer; // Get the artist information
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while getting artist information: " + ex.Message);
                return "Unknown Artist";
            }
        }


        private string GetAlbum(string filePath)
        {
            try
            {
                var file = TagLib.File.Create(filePath);
                return file.Tag.Album; // Get the album information
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while getting album information: " + ex.Message);
                return "Unknown Album";
            }
        }


        private string GetYear(string filePath)
        {
            try
            {
                var file = TagLib.File.Create(filePath);
                return file.Tag.Year.ToString(); // Get the year information
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while getting year information: " + ex.Message);
                return "Unknown Year";
            }
        }


        private BitmapImage GetAlbumArt(string filePath)
        {
            try
            {
                var file = TagLib.File.Create(filePath);
                var tag = file.Tag;

                if (tag.Pictures.Length > 0)
                {
                    var bin = tag.Pictures[0].Data.Data;
                    var bitmapImage = new BitmapImage();
                    bitmapImage.BeginInit();
                    bitmapImage.StreamSource = new MemoryStream(bin);
                    bitmapImage.EndInit();
                    return bitmapImage;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred while getting album art: " + ex.Message);
            }
            return null;
        }


        private void SetAlbumArt(string filePath)
        {
            BitmapImage albumArt = GetAlbumArt(filePath);
            if (albumArt != null)
            {
                Musicimg.Source = albumArt;
            }
            else
            {
                // Set a default image if album art is not available
                //Musicimg.Source = new BitmapImage(new Uri("Images/musicnote.png", UriKind.Relative));
                Musicimg.Source = new BitmapImage(new Uri("pack://application:,,,/Images/musicnote.png"));
            }
        }

        public class Song
        {
            public string Name { get; set; }
            public string Artist { get; set; }
            public string Album { get; set; }
            public int Year { get; set; }

            // Constructor
            public Song(string name, string artist, string album, int year)
            {
                Name = name;
                Artist = artist;
                Album = album;
                Year = year;
            }
        }

        private void FileMenu_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog(); // Open file dialog
            openFileDialog.Filter = "MP3 files (*.mp3)|*.mp3|All files (*.*)|*.*"; // Filter for mp3 files
            if (openFileDialog.ShowDialog() == true) // If file is selected
            {
                try
                {
                    // Open and play the selected MP3 file
                    mediaPlayer.Open(new Uri(openFileDialog.FileName));
                    mediaPlayer.Play();
                    // Update UI with file details
                    UpdateUI(openFileDialog.FileName);
                }
                catch (Exception ex) // Handle exceptions
                {
                    MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error); // Show error message
                }
            }
        }

        private void ControlsMenu_Click(object sender, RoutedEventArgs e)
        {
            // Get the button that was clicked
            Button button = sender as Button;

            // Get the context menu associated with the button
            ContextMenu contextMenu = button.ContextMenu;

            // Open the context menu
            contextMenu.IsOpen = true;
        }

        private void PlayMenu_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Play(); // Play the audio file
            timer.Start();  // Start the timer when media starts playing
            UpdatePlaybackTime(); // Update the playback time immediately
        }

        private void PauseMenu_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Pause(); // Pause the audio playback             
            timer.Stop();  // Stop the timer when media is paused
        }

        private void StopMenu_Click(object sender, RoutedEventArgs e)
        {
            mediaPlayer.Stop(); //Stop audio playback
            timer.Stop();
        }

        private void NextSongMenu_Click(object sender, RoutedEventArgs e)
        {
            PlayNextSong(); // Play the next song when the button is clicked
        }

        private void PreviousSongMenu_Click(object sender, RoutedEventArgs e)
        {
            PlayPreviousSong(); // Play the previous song when the button is clicked
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            PopulateSongTreeView("C:/music"); // Call a method to populate the TreeView with songs from the directory
        }

        private void PopulateSongTreeView(string directoryPath)
        {
            if (Directory.Exists(directoryPath))
            {
                DirectoryInfo directoryInfo = new DirectoryInfo(directoryPath);
                foreach (FileInfo file in directoryInfo.GetFiles("*.mp3")) // Assuming all songs are in .mp3 format
                {
                    SongTreeView.Items.Add(new TreeViewItem { Header = file.Name });
                }
            }
            else
            {
                MessageBox.Show("Directory not found.");
            }
        }

        // Event handler for song selection change
private void SongList_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Check if an item is selected
            if (SongTreeView.SelectedItem != null)
            {
                // Retrieve selected song's metadata
                Song selectedSong = (Song)SongTreeView.SelectedItem;

                // Populate UI elements with metadata for editing
                txtSongName.Text = selectedSong.Name;
                editArtist.Text = selectedSong.Artist;
                editAlbum.Text = selectedSong.Album;
                editYear.Text = selectedSong.Year.ToString();
            }
        }

        // Method to save changes to metadata
        private void SaveChanges_Click(object sender, RoutedEventArgs e)
        {
            // Retrieve selected song (assuming you have a reference to the song object)
            Song selectedSong = (Song)SongTreeView.SelectedItem;

            // Update metadata with changes from UI elements
            selectedSong.Name = txtSongName.Text;
            selectedSong.Artist = editArtist.Text;
            selectedSong.Album = editAlbum.Text;

            // Convert year from string to int (assuming Year is an integer property)
            if (int.TryParse(editYear.Text, out int year))
            {
                selectedSong.Year = year;
            }

            
        }
        

        private void EditButton_Click(object sender, RoutedEventArgs e)
        {
            // Update edited song information
            editedSongName = lblSongname.Text;
            editedArtist = editArtist.Text;
            editedAlbum = editAlbum.Text;
            editedYear = editYear.Text;

            try
            {
                // Load the MP3 file
                var file = TagLib.File.Create(mp3Files[currentSongIndex]);

                // Update the metadata
                file.Tag.Title = editedSongName;
                file.Tag.Performers = new[] { editedArtist };
                file.Tag.Album = editedAlbum;

                // Save the changes
                file.Save();

                // Disable editing for TextBoxes
                lblSongname.IsEnabled = false;
                editArtist.IsEnabled = false;
                editAlbum.IsEnabled = false;
                editYear.IsEnabled = false;

                // Reset the background color of TextBoxes
                //SolidColorBrush defaultBackground = new SolidColorBrush(Colors.Transparent);
               // lblSongname.Background = defaultBackground;
                //txtArtist.Background = defaultBackground;
               // txtAlbum.Background = defaultBackground;
                //txtYear.Background = defaultBackground;
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred while saving the edited information: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
